﻿
namespace MES_project
{
    partial class FormEquipStatus
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Series series2 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea2 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend2 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series3 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Series series4 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea3 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend3 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series5 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Series series6 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormEquipStatus));
            this.label_airCompStatus2 = new MetroFramework.Controls.MetroTabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.label_airCompStatus1 = new System.Windows.Forms.Label();
            this.label_airComp1 = new System.Windows.Forms.Label();
            this.label_tmpStat1 = new System.Windows.Forms.Label();
            this.label_tmpStatTitle1 = new System.Windows.Forms.Label();
            this.label_dt1 = new System.Windows.Forms.Label();
            this.label_ct1 = new System.Windows.Forms.Label();
            this.groupBox_dtSet1 = new System.Windows.Forms.GroupBox();
            this.btn_dtSet1 = new System.Windows.Forms.Button();
            this.btn_dtReset1 = new System.Windows.Forms.Button();
            this.trackBar1 = new System.Windows.Forms.TrackBar();
            this.tb_dtValue1 = new System.Windows.Forms.TextBox();
            this.chart_1ho = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.tb_ct1 = new System.Windows.Forms.TextBox();
            this.tb_dt1 = new System.Windows.Forms.TextBox();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.label_airCompStatus_2 = new System.Windows.Forms.Label();
            this.label_airComp2 = new System.Windows.Forms.Label();
            this.label_tmpStat2 = new System.Windows.Forms.Label();
            this.label_tmpStatTitle2 = new System.Windows.Forms.Label();
            this.label_dt2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btn_dtSet2 = new System.Windows.Forms.Button();
            this.btn_dtReset2 = new System.Windows.Forms.Button();
            this.trackBar2 = new System.Windows.Forms.TrackBar();
            this.tb_dtValue2 = new System.Windows.Forms.TextBox();
            this.chart_2ho = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.tb_ct2 = new System.Windows.Forms.TextBox();
            this.tb_dt2 = new System.Windows.Forms.TextBox();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.label_airCompStatus3 = new System.Windows.Forms.Label();
            this.label_airComp3 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label_tmpStatTitle3 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btn_dtSet3 = new System.Windows.Forms.Button();
            this.btn_dtReset3 = new System.Windows.Forms.Button();
            this.trackBar3 = new System.Windows.Forms.TrackBar();
            this.tb_dtValue3 = new System.Windows.Forms.TextBox();
            this.chart_3ho = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.tb_ct3 = new System.Windows.Forms.TextBox();
            this.tb_dt3 = new System.Windows.Forms.TextBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label_airCompStatus2.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.groupBox_dtSet1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart_1ho)).BeginInit();
            this.tabPage2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart_2ho)).BeginInit();
            this.tabPage3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart_3ho)).BeginInit();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // label_airCompStatus2
            // 
            this.label_airCompStatus2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label_airCompStatus2.Controls.Add(this.tabPage1);
            this.label_airCompStatus2.Controls.Add(this.tabPage2);
            this.label_airCompStatus2.Controls.Add(this.tabPage3);
            this.label_airCompStatus2.Location = new System.Drawing.Point(31, 28);
            this.label_airCompStatus2.Name = "label_airCompStatus2";
            this.label_airCompStatus2.SelectedIndex = 1;
            this.label_airCompStatus2.Size = new System.Drawing.Size(938, 466);
            this.label_airCompStatus2.TabIndex = 0;
            this.label_airCompStatus2.UseSelectable = true;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.label_airCompStatus1);
            this.tabPage1.Controls.Add(this.label_airComp1);
            this.tabPage1.Controls.Add(this.label_tmpStat1);
            this.tabPage1.Controls.Add(this.label_tmpStatTitle1);
            this.tabPage1.Controls.Add(this.label_dt1);
            this.tabPage1.Controls.Add(this.label_ct1);
            this.tabPage1.Controls.Add(this.groupBox_dtSet1);
            this.tabPage1.Controls.Add(this.chart_1ho);
            this.tabPage1.Controls.Add(this.tb_ct1);
            this.tabPage1.Controls.Add(this.tb_dt1);
            this.tabPage1.Font = new System.Drawing.Font("맑은 고딕", 10.8F);
            this.tabPage1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.tabPage1.Location = new System.Drawing.Point(4, 38);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Size = new System.Drawing.Size(930, 424);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "1호기";
            this.tabPage1.Click += new System.EventHandler(this.tabPage1_Click);
            // 
            // label_airCompStatus1
            // 
            this.label_airCompStatus1.AutoSize = true;
            this.label_airCompStatus1.Location = new System.Drawing.Point(205, 182);
            this.label_airCompStatus1.Name = "label_airCompStatus1";
            this.label_airCompStatus1.Size = new System.Drawing.Size(20, 25);
            this.label_airCompStatus1.TabIndex = 15;
            this.label_airCompStatus1.Text = "-";
            // 
            // label_airComp1
            // 
            this.label_airComp1.AutoSize = true;
            this.label_airComp1.Location = new System.Drawing.Point(108, 185);
            this.label_airComp1.Name = "label_airComp1";
            this.label_airComp1.Size = new System.Drawing.Size(69, 25);
            this.label_airComp1.TabIndex = 14;
            this.label_airComp1.Text = "공조기";
            // 
            // label_tmpStat1
            // 
            this.label_tmpStat1.AutoSize = true;
            this.label_tmpStat1.Location = new System.Drawing.Point(196, 227);
            this.label_tmpStat1.Name = "label_tmpStat1";
            this.label_tmpStat1.Size = new System.Drawing.Size(50, 25);
            this.label_tmpStat1.TabIndex = 13;
            this.label_tmpStat1.Text = "적정";
            // 
            // label_tmpStatTitle1
            // 
            this.label_tmpStatTitle1.AutoSize = true;
            this.label_tmpStatTitle1.Location = new System.Drawing.Point(99, 226);
            this.label_tmpStatTitle1.Name = "label_tmpStatTitle1";
            this.label_tmpStatTitle1.Size = new System.Drawing.Size(88, 25);
            this.label_tmpStatTitle1.TabIndex = 12;
            this.label_tmpStatTitle1.Text = "온도상태";
            // 
            // label_dt1
            // 
            this.label_dt1.AutoSize = true;
            this.label_dt1.Location = new System.Drawing.Point(201, 63);
            this.label_dt1.Name = "label_dt1";
            this.label_dt1.Size = new System.Drawing.Size(95, 25);
            this.label_dt1.TabIndex = 11;
            this.label_dt1.Text = "설정 온도";
            // 
            // label_ct1
            // 
            this.label_ct1.AutoSize = true;
            this.label_ct1.Location = new System.Drawing.Point(72, 63);
            this.label_ct1.Name = "label_ct1";
            this.label_ct1.Size = new System.Drawing.Size(95, 25);
            this.label_ct1.TabIndex = 10;
            this.label_ct1.Text = "현재 온도";
            // 
            // groupBox_dtSet1
            // 
            this.groupBox_dtSet1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.groupBox_dtSet1.Controls.Add(this.btn_dtSet1);
            this.groupBox_dtSet1.Controls.Add(this.btn_dtReset1);
            this.groupBox_dtSet1.Controls.Add(this.trackBar1);
            this.groupBox_dtSet1.Controls.Add(this.tb_dtValue1);
            this.groupBox_dtSet1.Font = new System.Drawing.Font("맑은 고딕", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.groupBox_dtSet1.Location = new System.Drawing.Point(29, 260);
            this.groupBox_dtSet1.Name = "groupBox_dtSet1";
            this.groupBox_dtSet1.Size = new System.Drawing.Size(299, 138);
            this.groupBox_dtSet1.TabIndex = 9;
            this.groupBox_dtSet1.TabStop = false;
            this.groupBox_dtSet1.Text = "설정온도 변경";
            // 
            // btn_dtSet1
            // 
            this.btn_dtSet1.Location = new System.Drawing.Point(166, 86);
            this.btn_dtSet1.Name = "btn_dtSet1";
            this.btn_dtSet1.Size = new System.Drawing.Size(75, 34);
            this.btn_dtSet1.TabIndex = 9;
            this.btn_dtSet1.Text = "변경";
            this.btn_dtSet1.UseVisualStyleBackColor = true;
            this.btn_dtSet1.Click += new System.EventHandler(this.btn_dtSet1_Click);
            // 
            // btn_dtReset1
            // 
            this.btn_dtReset1.Location = new System.Drawing.Point(63, 86);
            this.btn_dtReset1.Name = "btn_dtReset1";
            this.btn_dtReset1.Size = new System.Drawing.Size(75, 34);
            this.btn_dtReset1.TabIndex = 9;
            this.btn_dtReset1.Text = "초기화";
            this.btn_dtReset1.UseVisualStyleBackColor = true;
            this.btn_dtReset1.Click += new System.EventHandler(this.btn_dtReset1_Click);
            // 
            // trackBar1
            // 
            this.trackBar1.Location = new System.Drawing.Point(6, 34);
            this.trackBar1.Maximum = 200;
            this.trackBar1.Minimum = -50;
            this.trackBar1.Name = "trackBar1";
            this.trackBar1.Size = new System.Drawing.Size(186, 56);
            this.trackBar1.TabIndex = 4;
            this.trackBar1.Scroll += new System.EventHandler(this.trackBar1_Scroll);
            // 
            // tb_dtValue1
            // 
            this.tb_dtValue1.Location = new System.Drawing.Point(207, 35);
            this.tb_dtValue1.Name = "tb_dtValue1";
            this.tb_dtValue1.Size = new System.Drawing.Size(45, 30);
            this.tb_dtValue1.TabIndex = 5;
            // 
            // chart_1ho
            // 
            this.chart_1ho.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            chartArea1.Name = "ChartArea1";
            this.chart_1ho.ChartAreas.Add(chartArea1);
            legend1.Name = "Legend1";
            this.chart_1ho.Legends.Add(legend1);
            this.chart_1ho.Location = new System.Drawing.Point(356, 24);
            this.chart_1ho.Name = "chart_1ho";
            series1.ChartArea = "ChartArea1";
            series1.Legend = "Legend1";
            series1.Name = "Series1";
            series2.ChartArea = "ChartArea1";
            series2.Legend = "Legend1";
            series2.Name = "Series2";
            this.chart_1ho.Series.Add(series1);
            this.chart_1ho.Series.Add(series2);
            this.chart_1ho.Size = new System.Drawing.Size(541, 374);
            this.chart_1ho.TabIndex = 6;
            this.chart_1ho.Text = "chart1";
            // 
            // tb_ct1
            // 
            this.tb_ct1.BackColor = System.Drawing.Color.White;
            this.tb_ct1.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_ct1.Location = new System.Drawing.Point(67, 110);
            this.tb_ct1.Multiline = true;
            this.tb_ct1.Name = "tb_ct1";
            this.tb_ct1.ReadOnly = true;
            this.tb_ct1.Size = new System.Drawing.Size(100, 60);
            this.tb_ct1.TabIndex = 3;
            this.tb_ct1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb_dt1
            // 
            this.tb_dt1.BackColor = System.Drawing.Color.White;
            this.tb_dt1.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Bold);
            this.tb_dt1.Location = new System.Drawing.Point(195, 110);
            this.tb_dt1.Multiline = true;
            this.tb_dt1.Name = "tb_dt1";
            this.tb_dt1.ReadOnly = true;
            this.tb_dt1.Size = new System.Drawing.Size(100, 60);
            this.tb_dt1.TabIndex = 2;
            this.tb_dt1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.label_airCompStatus_2);
            this.tabPage2.Controls.Add(this.label_airComp2);
            this.tabPage2.Controls.Add(this.label_tmpStat2);
            this.tabPage2.Controls.Add(this.label_tmpStatTitle2);
            this.tabPage2.Controls.Add(this.label_dt2);
            this.tabPage2.Controls.Add(this.label4);
            this.tabPage2.Controls.Add(this.groupBox1);
            this.tabPage2.Controls.Add(this.chart_2ho);
            this.tabPage2.Controls.Add(this.tb_ct2);
            this.tabPage2.Controls.Add(this.tb_dt2);
            this.tabPage2.Font = new System.Drawing.Font("맑은 고딕", 10.8F);
            this.tabPage2.Location = new System.Drawing.Point(4, 38);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Size = new System.Drawing.Size(930, 424);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "2호기";
            // 
            // label_airCompStatus_2
            // 
            this.label_airCompStatus_2.AutoSize = true;
            this.label_airCompStatus_2.Location = new System.Drawing.Point(205, 182);
            this.label_airCompStatus_2.Name = "label_airCompStatus_2";
            this.label_airCompStatus_2.Size = new System.Drawing.Size(20, 25);
            this.label_airCompStatus_2.TabIndex = 23;
            this.label_airCompStatus_2.Text = "-";
            // 
            // label_airComp2
            // 
            this.label_airComp2.AutoSize = true;
            this.label_airComp2.Location = new System.Drawing.Point(108, 185);
            this.label_airComp2.Name = "label_airComp2";
            this.label_airComp2.Size = new System.Drawing.Size(69, 25);
            this.label_airComp2.TabIndex = 22;
            this.label_airComp2.Text = "공조기";
            // 
            // label_tmpStat2
            // 
            this.label_tmpStat2.AutoSize = true;
            this.label_tmpStat2.Location = new System.Drawing.Point(196, 227);
            this.label_tmpStat2.Name = "label_tmpStat2";
            this.label_tmpStat2.Size = new System.Drawing.Size(50, 25);
            this.label_tmpStat2.TabIndex = 21;
            this.label_tmpStat2.Text = "적정";
            // 
            // label_tmpStatTitle2
            // 
            this.label_tmpStatTitle2.AutoSize = true;
            this.label_tmpStatTitle2.Location = new System.Drawing.Point(99, 226);
            this.label_tmpStatTitle2.Name = "label_tmpStatTitle2";
            this.label_tmpStatTitle2.Size = new System.Drawing.Size(88, 25);
            this.label_tmpStatTitle2.TabIndex = 20;
            this.label_tmpStatTitle2.Text = "온도상태";
            // 
            // label_dt2
            // 
            this.label_dt2.AutoSize = true;
            this.label_dt2.Location = new System.Drawing.Point(200, 63);
            this.label_dt2.Name = "label_dt2";
            this.label_dt2.Size = new System.Drawing.Size(95, 25);
            this.label_dt2.TabIndex = 19;
            this.label_dt2.Text = "설정 온도";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(71, 63);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(95, 25);
            this.label4.TabIndex = 18;
            this.label4.Text = "현재 온도";
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.groupBox1.Controls.Add(this.btn_dtSet2);
            this.groupBox1.Controls.Add(this.btn_dtReset2);
            this.groupBox1.Controls.Add(this.trackBar2);
            this.groupBox1.Controls.Add(this.tb_dtValue2);
            this.groupBox1.Font = new System.Drawing.Font("맑은 고딕", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.groupBox1.Location = new System.Drawing.Point(28, 261);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(299, 138);
            this.groupBox1.TabIndex = 17;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "설정온도 변경";
            // 
            // btn_dtSet2
            // 
            this.btn_dtSet2.Location = new System.Drawing.Point(166, 86);
            this.btn_dtSet2.Name = "btn_dtSet2";
            this.btn_dtSet2.Size = new System.Drawing.Size(75, 34);
            this.btn_dtSet2.TabIndex = 9;
            this.btn_dtSet2.Text = "변경";
            this.btn_dtSet2.UseVisualStyleBackColor = true;
            this.btn_dtSet2.Click += new System.EventHandler(this.btn_dtSet2_Click);
            // 
            // btn_dtReset2
            // 
            this.btn_dtReset2.Location = new System.Drawing.Point(63, 86);
            this.btn_dtReset2.Name = "btn_dtReset2";
            this.btn_dtReset2.Size = new System.Drawing.Size(75, 34);
            this.btn_dtReset2.TabIndex = 9;
            this.btn_dtReset2.Text = "초기화";
            this.btn_dtReset2.UseVisualStyleBackColor = true;
            this.btn_dtReset2.Click += new System.EventHandler(this.btn_dtReset2_Click);
            // 
            // trackBar2
            // 
            this.trackBar2.Location = new System.Drawing.Point(6, 34);
            this.trackBar2.Maximum = 200;
            this.trackBar2.Minimum = -50;
            this.trackBar2.Name = "trackBar2";
            this.trackBar2.Size = new System.Drawing.Size(186, 56);
            this.trackBar2.TabIndex = 4;
            this.trackBar2.Scroll += new System.EventHandler(this.trackBar2_Scroll);
            // 
            // tb_dtValue2
            // 
            this.tb_dtValue2.Location = new System.Drawing.Point(207, 35);
            this.tb_dtValue2.Name = "tb_dtValue2";
            this.tb_dtValue2.Size = new System.Drawing.Size(45, 30);
            this.tb_dtValue2.TabIndex = 5;
            // 
            // chart_2ho
            // 
            this.chart_2ho.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            chartArea2.Name = "ChartArea1";
            this.chart_2ho.ChartAreas.Add(chartArea2);
            legend2.Name = "Legend1";
            this.chart_2ho.Legends.Add(legend2);
            this.chart_2ho.Location = new System.Drawing.Point(363, 25);
            this.chart_2ho.Name = "chart_2ho";
            series3.ChartArea = "ChartArea1";
            series3.Legend = "Legend1";
            series3.Name = "Series1";
            series4.ChartArea = "ChartArea1";
            series4.Legend = "Legend1";
            series4.Name = "Series2";
            this.chart_2ho.Series.Add(series3);
            this.chart_2ho.Series.Add(series4);
            this.chart_2ho.Size = new System.Drawing.Size(542, 374);
            this.chart_2ho.TabIndex = 16;
            this.chart_2ho.Text = "chart1";
            // 
            // tb_ct2
            // 
            this.tb_ct2.BackColor = System.Drawing.Color.White;
            this.tb_ct2.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_ct2.Location = new System.Drawing.Point(66, 110);
            this.tb_ct2.Multiline = true;
            this.tb_ct2.Name = "tb_ct2";
            this.tb_ct2.ReadOnly = true;
            this.tb_ct2.Size = new System.Drawing.Size(100, 60);
            this.tb_ct2.TabIndex = 15;
            this.tb_ct2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb_dt2
            // 
            this.tb_dt2.BackColor = System.Drawing.Color.White;
            this.tb_dt2.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Bold);
            this.tb_dt2.Location = new System.Drawing.Point(194, 110);
            this.tb_dt2.Multiline = true;
            this.tb_dt2.Name = "tb_dt2";
            this.tb_dt2.ReadOnly = true;
            this.tb_dt2.Size = new System.Drawing.Size(100, 60);
            this.tb_dt2.TabIndex = 14;
            this.tb_dt2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.label_airCompStatus3);
            this.tabPage3.Controls.Add(this.label_airComp3);
            this.tabPage3.Controls.Add(this.label5);
            this.tabPage3.Controls.Add(this.label_tmpStatTitle3);
            this.tabPage3.Controls.Add(this.label7);
            this.tabPage3.Controls.Add(this.label8);
            this.tabPage3.Controls.Add(this.groupBox2);
            this.tabPage3.Controls.Add(this.chart_3ho);
            this.tabPage3.Controls.Add(this.tb_ct3);
            this.tabPage3.Controls.Add(this.tb_dt3);
            this.tabPage3.Font = new System.Drawing.Font("맑은 고딕", 10.8F);
            this.tabPage3.Location = new System.Drawing.Point(4, 38);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(930, 424);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "3호기";
            // 
            // label_airCompStatus3
            // 
            this.label_airCompStatus3.AutoSize = true;
            this.label_airCompStatus3.Location = new System.Drawing.Point(206, 182);
            this.label_airCompStatus3.Name = "label_airCompStatus3";
            this.label_airCompStatus3.Size = new System.Drawing.Size(20, 25);
            this.label_airCompStatus3.TabIndex = 23;
            this.label_airCompStatus3.Text = "-";
            // 
            // label_airComp3
            // 
            this.label_airComp3.AutoSize = true;
            this.label_airComp3.Location = new System.Drawing.Point(109, 185);
            this.label_airComp3.Name = "label_airComp3";
            this.label_airComp3.Size = new System.Drawing.Size(69, 25);
            this.label_airComp3.TabIndex = 22;
            this.label_airComp3.Text = "공조기";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(196, 227);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(50, 25);
            this.label5.TabIndex = 21;
            this.label5.Text = "적정";
            // 
            // label_tmpStatTitle3
            // 
            this.label_tmpStatTitle3.AutoSize = true;
            this.label_tmpStatTitle3.Location = new System.Drawing.Point(99, 226);
            this.label_tmpStatTitle3.Name = "label_tmpStatTitle3";
            this.label_tmpStatTitle3.Size = new System.Drawing.Size(88, 25);
            this.label_tmpStatTitle3.TabIndex = 20;
            this.label_tmpStatTitle3.Text = "온도상태";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(200, 63);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(95, 25);
            this.label7.TabIndex = 19;
            this.label7.Text = "설정 온도";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(71, 63);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(95, 25);
            this.label8.TabIndex = 18;
            this.label8.Text = "현재 온도";
            // 
            // groupBox2
            // 
            this.groupBox2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.groupBox2.Controls.Add(this.btn_dtSet3);
            this.groupBox2.Controls.Add(this.btn_dtReset3);
            this.groupBox2.Controls.Add(this.trackBar3);
            this.groupBox2.Controls.Add(this.tb_dtValue3);
            this.groupBox2.Font = new System.Drawing.Font("맑은 고딕", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.groupBox2.Location = new System.Drawing.Point(28, 261);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(299, 138);
            this.groupBox2.TabIndex = 17;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "설정온도 변경";
            // 
            // btn_dtSet3
            // 
            this.btn_dtSet3.Location = new System.Drawing.Point(166, 86);
            this.btn_dtSet3.Name = "btn_dtSet3";
            this.btn_dtSet3.Size = new System.Drawing.Size(75, 34);
            this.btn_dtSet3.TabIndex = 9;
            this.btn_dtSet3.Text = "변경";
            this.btn_dtSet3.UseVisualStyleBackColor = true;
            this.btn_dtSet3.Click += new System.EventHandler(this.btn_dtSet3_Click);
            // 
            // btn_dtReset3
            // 
            this.btn_dtReset3.Location = new System.Drawing.Point(63, 86);
            this.btn_dtReset3.Name = "btn_dtReset3";
            this.btn_dtReset3.Size = new System.Drawing.Size(75, 34);
            this.btn_dtReset3.TabIndex = 9;
            this.btn_dtReset3.Text = "초기화";
            this.btn_dtReset3.UseVisualStyleBackColor = true;
            this.btn_dtReset3.Click += new System.EventHandler(this.btn_dtReset3_Click);
            // 
            // trackBar3
            // 
            this.trackBar3.Location = new System.Drawing.Point(6, 34);
            this.trackBar3.Maximum = 200;
            this.trackBar3.Minimum = -50;
            this.trackBar3.Name = "trackBar3";
            this.trackBar3.Size = new System.Drawing.Size(186, 56);
            this.trackBar3.TabIndex = 4;
            this.trackBar3.Scroll += new System.EventHandler(this.trackBar3_Scroll);
            // 
            // tb_dtValue3
            // 
            this.tb_dtValue3.Location = new System.Drawing.Point(207, 35);
            this.tb_dtValue3.Name = "tb_dtValue3";
            this.tb_dtValue3.Size = new System.Drawing.Size(45, 30);
            this.tb_dtValue3.TabIndex = 5;
            // 
            // chart_3ho
            // 
            this.chart_3ho.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            chartArea3.Name = "ChartArea1";
            this.chart_3ho.ChartAreas.Add(chartArea3);
            legend3.Name = "Legend1";
            this.chart_3ho.Legends.Add(legend3);
            this.chart_3ho.Location = new System.Drawing.Point(366, 25);
            this.chart_3ho.Name = "chart_3ho";
            series5.ChartArea = "ChartArea1";
            series5.Legend = "Legend1";
            series5.Name = "Series1";
            series6.ChartArea = "ChartArea1";
            series6.Legend = "Legend1";
            series6.Name = "Series2";
            this.chart_3ho.Series.Add(series5);
            this.chart_3ho.Series.Add(series6);
            this.chart_3ho.Size = new System.Drawing.Size(542, 356);
            this.chart_3ho.TabIndex = 16;
            this.chart_3ho.Text = "chart1";
            // 
            // tb_ct3
            // 
            this.tb_ct3.BackColor = System.Drawing.Color.White;
            this.tb_ct3.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_ct3.Location = new System.Drawing.Point(66, 110);
            this.tb_ct3.Multiline = true;
            this.tb_ct3.Name = "tb_ct3";
            this.tb_ct3.ReadOnly = true;
            this.tb_ct3.Size = new System.Drawing.Size(100, 60);
            this.tb_ct3.TabIndex = 15;
            this.tb_ct3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb_dt3
            // 
            this.tb_dt3.BackColor = System.Drawing.Color.White;
            this.tb_dt3.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Bold);
            this.tb_dt3.Location = new System.Drawing.Point(194, 110);
            this.tb_dt3.Multiline = true;
            this.tb_dt3.Name = "tb_dt3";
            this.tb_dt3.ReadOnly = true;
            this.tb_dt3.Size = new System.Drawing.Size(100, 60);
            this.tb_dt3.TabIndex = 14;
            this.tb_dt3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.label_airCompStatus2);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(981, 553);
            this.panel2.TabIndex = 2;
            // 
            // FormEquipStatus
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(981, 553);
            this.Controls.Add(this.panel2);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FormEquipStatus";
            this.Text = "FormEquipStatus";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.FormEquipStatus_FormClosed);
            this.Load += new System.EventHandler(this.FormEquipStatus_Load);
            this.label_airCompStatus2.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.groupBox_dtSet1.ResumeLayout(false);
            this.groupBox_dtSet1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart_1ho)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart_2ho)).EndInit();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart_3ho)).EndInit();
            this.panel2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private MetroFramework.Controls.MetroTabControl label_airCompStatus2;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.GroupBox groupBox_dtSet1;
        private System.Windows.Forms.TrackBar trackBar1;
        private System.Windows.Forms.TextBox tb_dtValue1;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart_1ho;
        private System.Windows.Forms.TextBox tb_ct1;
        private System.Windows.Forms.TextBox tb_dt1;
        private System.Windows.Forms.Label label_dt1;
        private System.Windows.Forms.Label label_ct1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label_tmpStat1;
        private System.Windows.Forms.Label label_tmpStatTitle1;
        private System.Windows.Forms.Button btn_dtSet1;
        private System.Windows.Forms.Button btn_dtReset1;
        private System.Windows.Forms.Label label_tmpStat2;
        private System.Windows.Forms.Label label_tmpStatTitle2;
        private System.Windows.Forms.Label label_dt2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btn_dtSet2;
        private System.Windows.Forms.Button btn_dtReset2;
        private System.Windows.Forms.TrackBar trackBar2;
        private System.Windows.Forms.TextBox tb_dtValue2;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart_2ho;
        private System.Windows.Forms.TextBox tb_ct2;
        private System.Windows.Forms.TextBox tb_dt2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label_tmpStatTitle3;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button btn_dtSet3;
        private System.Windows.Forms.Button btn_dtReset3;
        private System.Windows.Forms.TrackBar trackBar3;
        private System.Windows.Forms.TextBox tb_dtValue3;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart_3ho;
        private System.Windows.Forms.TextBox tb_ct3;
        private System.Windows.Forms.TextBox tb_dt3;
        private System.Windows.Forms.Label label_airCompStatus1;
        private System.Windows.Forms.Label label_airComp1;
        private System.Windows.Forms.Label label_airCompStatus_2;
        private System.Windows.Forms.Label label_airComp2;
        private System.Windows.Forms.Label label_airCompStatus3;
        private System.Windows.Forms.Label label_airComp3;
    }
}