﻿
namespace MES_project
{
    partial class FormOperationStatus
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox_equip = new System.Windows.Forms.GroupBox();
            this.label_3ho = new System.Windows.Forms.Label();
            this.label_2ho = new System.Windows.Forms.Label();
            this.label_1ho = new System.Windows.Forms.Label();
            this.btn_3ho = new MetroFramework.Controls.MetroButton();
            this.btn_2ho = new MetroFramework.Controls.MetroButton();
            this.btn_1ho = new MetroFramework.Controls.MetroButton();
            this.metroTabControl1 = new MetroFramework.Controls.MetroTabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.ListView_1ho = new System.Windows.Forms.ListView();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.ListView_2ho = new System.Windows.Forms.ListView();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.ListView_3ho = new System.Windows.Forms.ListView();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.groupBox_equip.SuspendLayout();
            this.metroTabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox_equip
            // 
            this.groupBox_equip.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox_equip.Controls.Add(this.label_3ho);
            this.groupBox_equip.Controls.Add(this.label_2ho);
            this.groupBox_equip.Controls.Add(this.label_1ho);
            this.groupBox_equip.Controls.Add(this.btn_3ho);
            this.groupBox_equip.Controls.Add(this.btn_2ho);
            this.groupBox_equip.Controls.Add(this.btn_1ho);
            this.groupBox_equip.Location = new System.Drawing.Point(12, 19);
            this.groupBox_equip.Name = "groupBox_equip";
            this.groupBox_equip.Size = new System.Drawing.Size(483, 393);
            this.groupBox_equip.TabIndex = 2;
            this.groupBox_equip.TabStop = false;
            this.groupBox_equip.Text = "설비배치";
            // 
            // label_3ho
            // 
            this.label_3ho.AutoSize = true;
            this.label_3ho.Location = new System.Drawing.Point(271, 120);
            this.label_3ho.Name = "label_3ho";
            this.label_3ho.Size = new System.Drawing.Size(47, 20);
            this.label_3ho.TabIndex = 3;
            this.label_3ho.Text = "3호기";
            // 
            // label_2ho
            // 
            this.label_2ho.AutoSize = true;
            this.label_2ho.Location = new System.Drawing.Point(183, 29);
            this.label_2ho.Name = "label_2ho";
            this.label_2ho.Size = new System.Drawing.Size(47, 20);
            this.label_2ho.TabIndex = 2;
            this.label_2ho.Text = "2호기";
            // 
            // label_1ho
            // 
            this.label_1ho.AutoSize = true;
            this.label_1ho.Location = new System.Drawing.Point(96, 30);
            this.label_1ho.Name = "label_1ho";
            this.label_1ho.Size = new System.Drawing.Size(47, 20);
            this.label_1ho.TabIndex = 1;
            this.label_1ho.Text = "1호기";
            // 
            // btn_3ho
            // 
            this.btn_3ho.Location = new System.Drawing.Point(253, 143);
            this.btn_3ho.Name = "btn_3ho";
            this.btn_3ho.Size = new System.Drawing.Size(82, 71);
            this.btn_3ho.TabIndex = 0;
            this.btn_3ho.Text = "3호기";
            this.btn_3ho.UseCustomBackColor = true;
            this.btn_3ho.UseSelectable = true;
            // 
            // btn_2ho
            // 
            this.btn_2ho.Location = new System.Drawing.Point(167, 51);
            this.btn_2ho.Name = "btn_2ho";
            this.btn_2ho.Size = new System.Drawing.Size(82, 71);
            this.btn_2ho.TabIndex = 0;
            this.btn_2ho.Text = "2호기";
            this.btn_2ho.UseCustomBackColor = true;
            this.btn_2ho.UseSelectable = true;
            // 
            // btn_1ho
            // 
            this.btn_1ho.Location = new System.Drawing.Point(79, 51);
            this.btn_1ho.Name = "btn_1ho";
            this.btn_1ho.Size = new System.Drawing.Size(82, 71);
            this.btn_1ho.TabIndex = 0;
            this.btn_1ho.Text = "1호기";
            this.btn_1ho.UseCustomBackColor = true;
            this.btn_1ho.UseSelectable = true;
            // 
            // metroTabControl1
            // 
            this.metroTabControl1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.metroTabControl1.Controls.Add(this.tabPage1);
            this.metroTabControl1.Controls.Add(this.tabPage2);
            this.metroTabControl1.Controls.Add(this.tabPage3);
            this.metroTabControl1.Location = new System.Drawing.Point(25, 25);
            this.metroTabControl1.Name = "metroTabControl1";
            this.metroTabControl1.SelectedIndex = 2;
            this.metroTabControl1.Size = new System.Drawing.Size(364, 393);
            this.metroTabControl1.TabIndex = 3;
            this.metroTabControl1.UseSelectable = true;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.ListView_1ho);
            this.tabPage1.Location = new System.Drawing.Point(4, 38);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Size = new System.Drawing.Size(356, 351);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "1호기";
            // 
            // ListView_1ho
            // 
            this.ListView_1ho.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.ListView_1ho.HideSelection = false;
            this.ListView_1ho.Location = new System.Drawing.Point(0, 0);
            this.ListView_1ho.Name = "ListView_1ho";
            this.ListView_1ho.Size = new System.Drawing.Size(353, 353);
            this.ListView_1ho.TabIndex = 1;
            this.ListView_1ho.UseCompatibleStateImageBehavior = false;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.ListView_2ho);
            this.tabPage2.Location = new System.Drawing.Point(4, 38);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Size = new System.Drawing.Size(356, 351);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "2호기";
            // 
            // ListView_2ho
            // 
            this.ListView_2ho.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.ListView_2ho.HideSelection = false;
            this.ListView_2ho.Location = new System.Drawing.Point(0, 0);
            this.ListView_2ho.Name = "ListView_2ho";
            this.ListView_2ho.Size = new System.Drawing.Size(356, 353);
            this.ListView_2ho.TabIndex = 2;
            this.ListView_2ho.UseCompatibleStateImageBehavior = false;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.ListView_3ho);
            this.tabPage3.Location = new System.Drawing.Point(4, 38);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(356, 351);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "3호기";
            // 
            // ListView_3ho
            // 
            this.ListView_3ho.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.ListView_3ho.HideSelection = false;
            this.ListView_3ho.Location = new System.Drawing.Point(1, 0);
            this.ListView_3ho.Name = "ListView_3ho";
            this.ListView_3ho.Size = new System.Drawing.Size(355, 355);
            this.ListView_3ho.TabIndex = 0;
            this.ListView_3ho.UseCompatibleStateImageBehavior = false;
            // 
            // splitContainer1
            // 
            this.splitContainer1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.splitContainer1.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.splitContainer1.IsSplitterFixed = true;
            this.splitContainer1.Location = new System.Drawing.Point(27, 58);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.groupBox_equip);
            this.splitContainer1.Panel1MinSize = 50;
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.metroTabControl1);
            this.splitContainer1.Size = new System.Drawing.Size(929, 493);
            this.splitContainer1.SplitterDistance = 516;
            this.splitContainer1.TabIndex = 4;
            // 
            // FormOperationStatus
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(981, 553);
            this.Controls.Add(this.splitContainer1);
            this.Name = "FormOperationStatus";
            this.Text = "FormOperationStatus";
            this.Load += new System.EventHandler(this.FormOperationStatus_Load);
            this.groupBox_equip.ResumeLayout(false);
            this.groupBox_equip.PerformLayout();
            this.metroTabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.tabPage3.ResumeLayout(false);
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.GroupBox groupBox_equip;
        private MetroFramework.Controls.MetroButton btn_3ho;
        private MetroFramework.Controls.MetroButton btn_2ho;
        private MetroFramework.Controls.MetroButton btn_1ho;
        private MetroFramework.Controls.MetroTabControl metroTabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.ListView ListView_1ho;
        private System.Windows.Forms.ListView ListView_2ho;
        private System.Windows.Forms.ListView ListView_3ho;
        private System.Windows.Forms.Label label_3ho;
        private System.Windows.Forms.Label label_2ho;
        private System.Windows.Forms.Label label_1ho;
    }
}